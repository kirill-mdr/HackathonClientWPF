namespace SharedLibrary;

public enum SessionType
{
	DefaultSession,
	Shift,
	Transition
}