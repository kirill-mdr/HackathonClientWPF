namespace SharedLibrary;

public class EnvironmentIndicators
{
	public DateTime ReadTime { get; set; }
	public float Pressure { get; set; }
	public float Humidity { get; set; }
	public float Temperature { get; set; }
}