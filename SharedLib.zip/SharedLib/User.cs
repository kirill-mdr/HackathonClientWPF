﻿namespace SharedLibrary;

public class User
{
	
}